/**
 * Created by zhaodagang on 2016/6/23.
 *	配置模块加载地址
 */
seajs.config({
	base:'./js'
});